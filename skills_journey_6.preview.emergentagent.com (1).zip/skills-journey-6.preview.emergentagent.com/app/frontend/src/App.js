import React from "react";
import "./App.css";
import { BrowserRouter, Routes, Route } from "react-router-dom";
import Navigation from "./components/Navigation";
import Footer from "./components/Footer";
import Home from "./pages/Home";
import About from "./pages/About";
import Mission from "./pages/Mission";
import StrengthsOverview from "./pages/StrengthsOverview";
import StrengthDetail from "./pages/StrengthDetail";
import ILP from "./pages/ILP";
import VisionBoard from "./pages/VisionBoard";
import Projects from "./pages/Projects";
import Editor from "./pages/Editor";
import { Toaster } from "./components/ui/toaster";

function App() {
  return (
    <div className="App">
      <BrowserRouter>
        <Navigation />
        <div className="pt-20">
          <Routes>
            <Route path="/" element={<Home />} />
            <Route path="/about" element={<About />} />
            <Route path="/mission" element={<Mission />} />
            <Route path="/strengths/:strengthId" element={<StrengthDetail />} />
            <Route path="/strengths" element={<StrengthsOverview />} />
            <Route path="/ilp" element={<ILP />} />
            <Route path="/vision" element={<VisionBoard />} />
            <Route path="/projects" element={<Projects />} />
            <Route path="/editor" element={<Editor />} />
          </Routes>
        </div>
        <Footer />
        <Toaster />
      </BrowserRouter>
    </div>
  );
}

export default App;

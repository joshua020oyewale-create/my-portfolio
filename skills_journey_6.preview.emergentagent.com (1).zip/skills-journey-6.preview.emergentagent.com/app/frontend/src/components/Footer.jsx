import React from 'react';
import { Mail, Linkedin, Github } from 'lucide-react';

const Footer = () => {
  return (
    <footer className="bg-[#3E2723] text-[#FAF8F3] py-12 mt-20">
      <div className="max-w-7xl mx-auto px-6 lg:px-8">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          {/* About Section */}
          <div>
            <h3
              className="text-2xl font-bold mb-4 text-[#C9A961]"
              style={{ fontFamily: 'Playfair Display, serif' }}
            >
              Joshua
            </h3>
            <p className="text-[#D4C5B0] leading-relaxed">
              Pre-Med Student at University of the Fraser Valley, dedicated to using science and
              compassion to improve lives.
            </p>
          </div>

          {/* Quick Links */}
          <div>
            <h4 className="text-lg font-semibold mb-4 text-[#C9A961]">Quick Links</h4>
            <ul className="space-y-2">
              <li>
                <a href="/about" className="text-[#D4C5B0] hover:text-[#C9A961] transition-colors">
                  About Me
                </a>
              </li>
              <li>
                <a href="/mission" className="text-[#D4C5B0] hover:text-[#C9A961] transition-colors">
                  Mission Statement
                </a>
              </li>
              <li>
                <a href="/vision" className="text-[#D4C5B0] hover:text-[#C9A961] transition-colors">
                  Vision Board
                </a>
              </li>
              <li>
                <a href="/projects" className="text-[#D4C5B0] hover:text-[#C9A961] transition-colors">
                  Projects
                </a>
              </li>
            </ul>
          </div>

          {/* Contact */}
          <div>
            <h4 className="text-lg font-semibold mb-4 text-[#C9A961]">Connect</h4>
            <div className="flex space-x-4">
              <a
                href="mailto:joshua@example.com"
                className="p-3 bg-[#4A403A] rounded-full hover:bg-[#C9A961] transition-all transform hover:scale-110"
                aria-label="Email"
              >
                <Mail size={20} />
              </a>
              <a
                href="https://linkedin.com"
                target="_blank"
                rel="noopener noreferrer"
                className="p-3 bg-[#4A403A] rounded-full hover:bg-[#C9A961] transition-all transform hover:scale-110"
                aria-label="LinkedIn"
              >
                <Linkedin size={20} />
              </a>
              <a
                href="https://github.com"
                target="_blank"
                rel="noopener noreferrer"
                className="p-3 bg-[#4A403A] rounded-full hover:bg-[#C9A961] transition-all transform hover:scale-110"
                aria-label="GitHub"
              >
                <Github size={20} />
              </a>
            </div>
          </div>
        </div>

        {/* Copyright */}
        <div className="border-t border-[#4A403A] mt-8 pt-8 text-center text-[#D4C5B0]">
          <p>&copy; {new Date().getFullYear()} Joshua. All rights reserved.</p>
          <p className="mt-2 text-sm">Digital Career Portfolio</p>
        </div>
      </div>
    </footer>
  );
};

export default Footer;

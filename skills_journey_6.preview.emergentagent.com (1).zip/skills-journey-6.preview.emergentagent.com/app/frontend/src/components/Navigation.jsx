import React, { useState } from 'react';
import { Link, useLocation } from 'react-router-dom';
import {
  NavigationMenu,
  NavigationMenuContent,
  NavigationMenuItem,
  NavigationMenuLink,
  NavigationMenuList,
  NavigationMenuTrigger,
} from './ui/navigation-menu';
import { Menu, X } from 'lucide-react';
import { cn } from '../lib/utils';

const Navigation = () => {
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);
  const location = useLocation();

  const isActive = (path) => location.pathname === path;

  const strengthsItems = [
    { title: 'Adaptability', path: '/strengths/adaptability' },
    { title: 'Critical Thinking', path: '/strengths/critical-thinking' },
    { title: 'Communication', path: '/strengths/communication' },
    { title: 'Teamwork', path: '/strengths/teamwork' },
    { title: 'Leadership', path: '/strengths/leadership' },
    { title: 'Resilience', path: '/strengths/resilience' },
    { title: 'Time Management', path: '/strengths/time-management' },
    { title: 'Empathy & Compassion', path: '/strengths/empathy' },
  ];

  return (
    <nav className="fixed top-0 left-0 right-0 z-50 bg-[#FAF8F3] border-b border-[#D4C5B0] shadow-sm">
      <div className="max-w-7xl mx-auto px-6 lg:px-8">
        <div className="flex items-center justify-between h-20">
          {/* Logo/Name */}
          <Link
            to="/"
            className="text-2xl font-bold text-[#3E2723] hover:text-[#C9A961] transition-colors"
            style={{ fontFamily: 'Playfair Display, serif' }}
          >
            Joshua
          </Link>

          {/* Desktop Navigation */}
          <div className="hidden lg:flex items-center space-x-1">
            <NavigationMenu>
              <NavigationMenuList>
                <NavigationMenuItem>
                  <Link
                    to="/"
                    className={cn(
                      "px-4 py-2 text-[#4A403A] hover:text-[#C9A961] transition-colors font-medium",
                      isActive('/') && "text-[#C9A961]"
                    )}
                  >
                    Home
                  </Link>
                </NavigationMenuItem>

                <NavigationMenuItem>
                  <Link
                    to="/about"
                    className={cn(
                      "px-4 py-2 text-[#4A403A] hover:text-[#C9A961] transition-colors font-medium",
                      isActive('/about') && "text-[#C9A961]"
                    )}
                  >
                    About
                  </Link>
                </NavigationMenuItem>

                <NavigationMenuItem>
                  <Link
                    to="/mission"
                    className={cn(
                      "px-4 py-2 text-[#4A403A] hover:text-[#C9A961] transition-colors font-medium",
                      isActive('/mission') && "text-[#C9A961]"
                    )}
                  >
                    Mission
                  </Link>
                </NavigationMenuItem>

                <NavigationMenuItem>
                  <NavigationMenuTrigger className="text-[#4A403A] hover:text-[#C9A961] font-medium">
                    Strengths
                  </NavigationMenuTrigger>
                  <NavigationMenuContent>
                    <ul className="grid w-[400px] gap-3 p-4 md:w-[500px] md:grid-cols-2">
                      {strengthsItems.map((item) => (
                        <li key={item.path}>
                          <NavigationMenuLink asChild>
                            <Link
                              to={item.path}
                              className="block select-none space-y-1 rounded-md p-3 leading-none no-underline outline-none transition-colors hover:bg-[#F5F1E8] hover:text-[#C9A961] focus:bg-[#F5F1E8] focus:text-[#C9A961]"
                            >
                              <div className="text-sm font-medium leading-none">{item.title}</div>
                            </Link>
                          </NavigationMenuLink>
                        </li>
                      ))}
                    </ul>
                  </NavigationMenuContent>
                </NavigationMenuItem>

                <NavigationMenuItem>
                  <Link
                    to="/ilp"
                    className={cn(
                      "px-4 py-2 text-[#4A403A] hover:text-[#C9A961] transition-colors font-medium",
                      isActive('/ilp') && "text-[#C9A961]"
                    )}
                  >
                    Life Planning
                  </Link>
                </NavigationMenuItem>

                <NavigationMenuItem>
                  <Link
                    to="/vision"
                    className={cn(
                      "px-4 py-2 text-[#4A403A] hover:text-[#C9A961] transition-colors font-medium",
                      isActive('/vision') && "text-[#C9A961]"
                    )}
                  >
                    Vision Board
                  </Link>
                </NavigationMenuItem>

                <NavigationMenuItem>
                  <Link
                    to="/projects"
                    className={cn(
                      "px-4 py-2 text-[#4A403A] hover:text-[#C9A961] transition-colors font-medium",
                      isActive('/projects') && "text-[#C9A961]"
                    )}
                  >
                    Projects
                  </Link>
                </NavigationMenuItem>

                <NavigationMenuItem>
                  <Link
                    to="/editor"
                    className={cn(
                      "px-4 py-2 text-white bg-[#C9A961] hover:bg-[#B89551] rounded-full transition-all font-medium ml-2",
                      isActive('/editor') && "bg-[#B89551]"
                    )}
                  >
                    Edit Portfolio
                  </Link>
                </NavigationMenuItem>
              </NavigationMenuList>
            </NavigationMenu>
          </div>

          {/* Mobile Menu Button */}
          <button
            className="lg:hidden p-2 text-[#4A403A] hover:text-[#C9A961] transition-colors"
            onClick={() => setIsMobileMenuOpen(!isMobileMenuOpen)}
          >
            {isMobileMenuOpen ? <X size={28} /> : <Menu size={28} />}
          </button>
        </div>
      </div>

      {/* Mobile Menu */}
      {isMobileMenuOpen && (
        <div className="lg:hidden bg-[#FAF8F3] border-t border-[#D4C5B0]">
          <div className="px-4 py-6 space-y-4">
            <Link
              to="/"
              className="block py-2 text-[#4A403A] hover:text-[#C9A961] transition-colors font-medium"
              onClick={() => setIsMobileMenuOpen(false)}
            >
              Home
            </Link>
            <Link
              to="/about"
              className="block py-2 text-[#4A403A] hover:text-[#C9A961] transition-colors font-medium"
              onClick={() => setIsMobileMenuOpen(false)}
            >
              About
            </Link>
            <Link
              to="/mission"
              className="block py-2 text-[#4A403A] hover:text-[#C9A961] transition-colors font-medium"
              onClick={() => setIsMobileMenuOpen(false)}
            >
              Mission
            </Link>
            <div className="py-2">
              <div className="font-semibold text-[#3E2723] mb-2">Strengths</div>
              <div className="pl-4 space-y-2">
                {strengthsItems.map((item) => (
                  <Link
                    key={item.path}
                    to={item.path}
                    className="block py-1 text-sm text-[#4A403A] hover:text-[#C9A961] transition-colors"
                    onClick={() => setIsMobileMenuOpen(false)}
                  >
                    {item.title}
                  </Link>
                ))}
              </div>
            </div>
            <Link
              to="/ilp"
              className="block py-2 text-[#4A403A] hover:text-[#C9A961] transition-colors font-medium"
              onClick={() => setIsMobileMenuOpen(false)}
            >
              Life Planning
            </Link>
            <Link
              to="/vision"
              className="block py-2 text-[#4A403A] hover:text-[#C9A961] transition-colors font-medium"
              onClick={() => setIsMobileMenuOpen(false)}
            >
              Vision Board
            </Link>
            <Link
              to="/projects"
              className="block py-2 text-[#4A403A] hover:text-[#C9A961] transition-colors font-medium"
              onClick={() => setIsMobileMenuOpen(false)}
            >
              Projects
            </Link>
            <Link
              to="/editor"
              className="block py-3 px-4 mt-4 text-center text-white bg-[#C9A961] hover:bg-[#B89551] rounded-full transition-colors font-semibold"
              onClick={() => setIsMobileMenuOpen(false)}
            >
              Edit Portfolio
            </Link>
          </div>
        </div>
      )}
    </nav>
  );
};

export default Navigation;

import React from 'react';
import { personalInfo, aboutMe } from '../data/mock';
import { GraduationCap, Heart, Sparkles } from 'lucide-react';

const About = () => {
  return (
    <div className="min-h-screen bg-[#FAF8F3] py-24 px-6">
      <div className="max-w-5xl mx-auto">
        {/* Header */}
        <div className="text-center mb-16">
          <h1
            className="text-5xl md:text-6xl font-bold text-[#3E2723] mb-6"
            style={{ fontFamily: 'Playfair Display, serif' }}
          >
            About Me
          </h1>
          <div className="w-24 h-1 bg-[#C9A961] mx-auto mb-8"></div>
        </div>

        {/* Profile Section */}
        <div className="bg-white rounded-3xl shadow-lg p-8 md:p-12 mb-12 border border-[#D4C5B0]">
          <div className="flex flex-col md:flex-row gap-8 items-center">
            {/* Profile Image */}
            <div className="flex-shrink-0">
              <div className="w-64 h-64 rounded-2xl overflow-hidden shadow-xl border-4 border-[#C9A961]">
                <img
                  src={personalInfo.profileImage}
                  alt={personalInfo.name}
                  className="w-full h-full object-cover"
                />
              </div>
            </div>

            {/* Profile Info */}
            <div className="flex-1 text-center md:text-left">
              <h2 className="text-4xl font-bold text-[#3E2723] mb-2" style={{ fontFamily: 'Playfair Display, serif' }}>
                {personalInfo.name}
              </h2>
              <p className="text-xl text-[#C9A961] mb-4 font-semibold">{personalInfo.title}</p>
              <p className="text-lg text-[#6B5D54] mb-6">{personalInfo.university}</p>
              
              <div className="flex flex-wrap gap-4 justify-center md:justify-start">
                <div className="flex items-center gap-2 bg-[#F5F1E8] px-4 py-2 rounded-full">
                  <GraduationCap className="text-[#C9A961]" size={20} />
                  <span className="text-[#4A403A] font-medium">Pre-Med Student</span>
                </div>
                <div className="flex items-center gap-2 bg-[#F5F1E8] px-4 py-2 rounded-full">
                  <Heart className="text-[#C89F91]" size={20} />
                  <span className="text-[#4A403A] font-medium">Community Volunteer</span>
                </div>
                <div className="flex items-center gap-2 bg-[#F5F1E8] px-4 py-2 rounded-full">
                  <Sparkles className="text-[#C9A961]" size={20} />
                  <span className="text-[#4A403A] font-medium">Aspiring Physician</span>
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* Introduction */}
        <div className="bg-white rounded-3xl shadow-lg p-8 md:p-12 mb-12 border border-[#D4C5B0]">
          <h3 className="text-3xl font-bold text-[#3E2723] mb-6" style={{ fontFamily: 'Playfair Display, serif' }}>
            My Journey
          </h3>
          <p className="text-lg text-[#4A403A] leading-relaxed mb-6">
            {aboutMe.introduction}
          </p>
          <p className="text-lg text-[#4A403A] leading-relaxed">
            {aboutMe.journey}
          </p>
        </div>

        {/* Key Experiences */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          <div className="bg-gradient-to-br from-[#F5F1E8] to-[#FAF8F3] rounded-2xl p-8 border border-[#D4C5B0] shadow-md hover:shadow-lg transition-shadow">
            <h4 className="text-2xl font-bold text-[#3E2723] mb-4">Academic Excellence</h4>
            <p className="text-[#4A403A] leading-relaxed">
              Pursuing rigorous pre-medical coursework in biology, chemistry, and research methodology while maintaining dedication to scientific inquiry and evidence-based practice.
            </p>
          </div>

          <div className="bg-gradient-to-br from-[#F5F1E8] to-[#FAF8F3] rounded-2xl p-8 border border-[#D4C5B0] shadow-md hover:shadow-lg transition-shadow">
            <h4 className="text-2xl font-bold text-[#3E2723] mb-4">Community Service</h4>
            <p className="text-[#4A403A] leading-relaxed">
              Active volunteer at community food bank and youth programs, developing empathy and understanding the social determinants of health through direct community engagement.
            </p>
          </div>

          <div className="bg-gradient-to-br from-[#F5F1E8] to-[#FAF8F3] rounded-2xl p-8 border border-[#D4C5B0] shadow-md hover:shadow-lg transition-shadow">
            <h4 className="text-2xl font-bold text-[#3E2723] mb-4">Leadership & Mentorship</h4>
            <p className="text-[#4A403A] leading-relaxed">
              Organized Black History Month events and student club activities, mentored younger students in science subjects, demonstrating commitment to uplifting others.
            </p>
          </div>

          <div className="bg-gradient-to-br from-[#F5F1E8] to-[#FAF8F3] rounded-2xl p-8 border border-[#D4C5B0] shadow-md hover:shadow-lg transition-shadow">
            <h4 className="text-2xl font-bold text-[#3E2723] mb-4">Work Experience</h4>
            <p className="text-[#4A403A] leading-relaxed">
              Developed teamwork and time management skills through part-time work at Superstore, learning to balance professional responsibilities with academic pursuits.
            </p>
          </div>
        </div>
      </div>
    </div>
  );
};

export default About;

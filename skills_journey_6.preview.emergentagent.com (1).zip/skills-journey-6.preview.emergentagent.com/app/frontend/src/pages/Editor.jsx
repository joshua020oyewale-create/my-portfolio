import React, { useState } from 'react';
import { Save, Edit, CheckCircle, AlertCircle } from 'lucide-react';
import { Button } from '../components/ui/button';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '../components/ui/tabs';
import { Input } from '../components/ui/input';
import { Textarea } from '../components/ui/textarea';
import { Label } from '../components/ui/label';
import { useToast } from '../hooks/use-toast';
import { 
  personalInfo as initialPersonalInfo, 
  missionStatement as initialMission,
  aboutMe as initialAboutMe,
  transferableSkills as initialSkills,
  ilpConcept as initialILP,
  visionBoard as initialVision,
  projects as initialProjects
} from '../data/mock';
import axios from 'axios';

const BACKEND_URL = process.env.REACT_APP_BACKEND_URL;
const API = `${BACKEND_URL}/api`;

const Editor = () => {
  const { toast } = useToast();
  const [saving, setSaving] = useState(false);
  
  // State for all editable content
  const [personalInfo, setPersonalInfo] = useState(initialPersonalInfo);
  const [missionStatement, setMissionStatement] = useState(initialMission);
  const [aboutMe, setAboutMe] = useState(initialAboutMe);
  const [transferableSkills, setTransferableSkills] = useState(initialSkills);
  const [ilpConcept, setIlpConcept] = useState(initialILP);
  const [visionBoard, setVisionBoard] = useState(initialVision);
  const [projects, setProjects] = useState(initialProjects);

  const handleSave = async () => {
    setSaving(true);
    try {
      const response = await axios.post(`${API}/content/update`, {
        personalInfo,
        missionStatement,
        aboutMe,
        transferableSkills,
        ilpConcept,
        visionBoard,
        projects
      });

      if (response.data.success) {
        toast({
          title: "Success!",
          description: "Your content has been saved. Refresh the page to see changes.",
          duration: 5000,
        });
      }
    } catch (error) {
      toast({
        title: "Error",
        description: "Failed to save content. Please try again.",
        variant: "destructive",
        duration: 5000,
      });
      console.error('Save error:', error);
    } finally {
      setSaving(false);
    }
  };

  const updateSkill = (index, field, value) => {
    const updated = [...transferableSkills];
    updated[index] = { ...updated[index], [field]: value };
    setTransferableSkills(updated);
  };

  const updateSkillExample = (skillIndex, exampleIndex, value) => {
    const updated = [...transferableSkills];
    updated[skillIndex].examples[exampleIndex] = value;
    setTransferableSkills(updated);
  };

  return (
    <div className="min-h-screen bg-[#FAF8F3] py-24 px-6">
      <div className="max-w-7xl mx-auto">
        {/* Header */}
        <div className="flex items-center justify-between mb-8">
          <div>
            <h1 className="text-4xl font-bold text-[#3E2723]" style={{ fontFamily: 'Playfair Display, serif' }}>
              Portfolio Editor
            </h1>
            <p className="text-[#6B5D54] mt-2">Edit your portfolio content easily</p>
          </div>
          <Button 
            onClick={handleSave} 
            disabled={saving}
            className="bg-[#C9A961] hover:bg-[#B89551] text-white"
            size="lg"
          >
            {saving ? (
              <>Saving...</>
            ) : (
              <>
                <Save className="mr-2" size={20} />
                Save All Changes
              </>
            )}
          </Button>
        </div>

        {/* Tabs for different sections */}
        <Tabs defaultValue="personal" className="w-full">
          <TabsList className="grid w-full grid-cols-4 lg:grid-cols-7 mb-8 bg-white border border-[#D4C5B0]">
            <TabsTrigger value="personal">Personal</TabsTrigger>
            <TabsTrigger value="about">About</TabsTrigger>
            <TabsTrigger value="mission">Mission</TabsTrigger>
            <TabsTrigger value="skills">Skills</TabsTrigger>
            <TabsTrigger value="ilp">Life Plan</TabsTrigger>
            <TabsTrigger value="vision">Vision</TabsTrigger>
            <TabsTrigger value="projects">Projects</TabsTrigger>
          </TabsList>

          {/* Personal Info Tab */}
          <TabsContent value="personal">
            <div className="bg-white rounded-3xl p-8 border border-[#D4C5B0] shadow-lg">
              <h2 className="text-2xl font-bold text-[#3E2723] mb-6">Personal Information</h2>
              <div className="space-y-6">
                <div>
                  <Label htmlFor="name">Name</Label>
                  <Input
                    id="name"
                    value={personalInfo.name}
                    onChange={(e) => setPersonalInfo({...personalInfo, name: e.target.value})}
                    className="mt-2"
                  />
                </div>
                <div>
                  <Label htmlFor="title">Title</Label>
                  <Input
                    id="title"
                    value={personalInfo.title}
                    onChange={(e) => setPersonalInfo({...personalInfo, title: e.target.value})}
                    className="mt-2"
                  />
                </div>
                <div>
                  <Label htmlFor="university">University</Label>
                  <Input
                    id="university"
                    value={personalInfo.university}
                    onChange={(e) => setPersonalInfo({...personalInfo, university: e.target.value})}
                    className="mt-2"
                  />
                </div>
                <div>
                  <Label htmlFor="email">Email</Label>
                  <Input
                    id="email"
                    type="email"
                    value={personalInfo.email}
                    onChange={(e) => setPersonalInfo({...personalInfo, email: e.target.value})}
                    className="mt-2"
                  />
                </div>
                <div>
                  <Label htmlFor="profileImage">Profile Image URL</Label>
                  <Input
                    id="profileImage"
                    value={personalInfo.profileImage}
                    onChange={(e) => setPersonalInfo({...personalInfo, profileImage: e.target.value})}
                    className="mt-2"
                  />
                  <p className="text-sm text-[#6B5D54] mt-1">Paste an image URL here</p>
                </div>
              </div>
            </div>
          </TabsContent>

          {/* About Me Tab */}
          <TabsContent value="about">
            <div className="bg-white rounded-3xl p-8 border border-[#D4C5B0] shadow-lg">
              <h2 className="text-2xl font-bold text-[#3E2723] mb-6">About Me</h2>
              <div className="space-y-6">
                <div>
                  <Label htmlFor="introduction">Introduction</Label>
                  <Textarea
                    id="introduction"
                    value={aboutMe.introduction}
                    onChange={(e) => setAboutMe({...aboutMe, introduction: e.target.value})}
                    className="mt-2 min-h-[150px]"
                  />
                </div>
                <div>
                  <Label htmlFor="journey">Journey</Label>
                  <Textarea
                    id="journey"
                    value={aboutMe.journey}
                    onChange={(e) => setAboutMe({...aboutMe, journey: e.target.value})}
                    className="mt-2 min-h-[150px]"
                  />
                </div>
              </div>
            </div>
          </TabsContent>

          {/* Mission Statement Tab */}
          <TabsContent value="mission">
            <div className="bg-white rounded-3xl p-8 border border-[#D4C5B0] shadow-lg">
              <h2 className="text-2xl font-bold text-[#3E2723] mb-6">Mission Statement</h2>
              <div>
                <Label htmlFor="mission">Your Mission</Label>
                <Textarea
                  id="mission"
                  value={missionStatement}
                  onChange={(e) => setMissionStatement(e.target.value)}
                  className="mt-2 min-h-[200px]"
                />
              </div>
            </div>
          </TabsContent>

          {/* Transferable Skills Tab */}
          <TabsContent value="skills">
            <div className="space-y-6">
              {transferableSkills.map((skill, index) => (
                <div key={skill.id} className="bg-white rounded-3xl p-8 border border-[#D4C5B0] shadow-lg">
                  <h2 className="text-2xl font-bold text-[#3E2723] mb-6">{skill.name}</h2>
                  <div className="space-y-4">
                    <div>
                      <Label>Tagline</Label>
                      <Input
                        value={skill.tagline}
                        onChange={(e) => updateSkill(index, 'tagline', e.target.value)}
                        className="mt-2"
                      />
                    </div>
                    <div>
                      <Label>Description (Short)</Label>
                      <Textarea
                        value={skill.description}
                        onChange={(e) => updateSkill(index, 'description', e.target.value)}
                        className="mt-2 min-h-[80px]"
                      />
                    </div>
                    <div>
                      <Label>Full Reflection</Label>
                      <Textarea
                        value={skill.fullReflection}
                        onChange={(e) => updateSkill(index, 'fullReflection', e.target.value)}
                        className="mt-2 min-h-[120px]"
                      />
                    </div>
                    <div>
                      <Label>Medical Connection</Label>
                      <Textarea
                        value={skill.medicalConnection}
                        onChange={(e) => updateSkill(index, 'medicalConnection', e.target.value)}
                        className="mt-2 min-h-[100px]"
                      />
                    </div>
                    <div>
                      <Label>Examples</Label>
                      {skill.examples.map((example, exIndex) => (
                        <Input
                          key={exIndex}
                          value={example}
                          onChange={(e) => updateSkillExample(index, exIndex, e.target.value)}
                          className="mt-2"
                          placeholder={`Example ${exIndex + 1}`}
                        />
                      ))}
                    </div>
                    <div>
                      <Label>Image URL</Label>
                      <Input
                        value={skill.image}
                        onChange={(e) => updateSkill(index, 'image', e.target.value)}
                        className="mt-2"
                      />
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </TabsContent>

          {/* ILP Tab */}
          <TabsContent value="ilp">
            <div className="bg-white rounded-3xl p-8 border border-[#D4C5B0] shadow-lg">
              <h2 className="text-2xl font-bold text-[#3E2723] mb-6">Integrative Life Planning</h2>
              <div className="space-y-6">
                <div>
                  <Label htmlFor="ilpTitle">Title</Label>
                  <Input
                    id="ilpTitle"
                    value={ilpConcept.title}
                    onChange={(e) => setIlpConcept({...ilpConcept, title: e.target.value})}
                    className="mt-2"
                  />
                </div>
                <div>
                  <Label htmlFor="ilpDesc">Description</Label>
                  <Textarea
                    id="ilpDesc"
                    value={ilpConcept.description}
                    onChange={(e) => setIlpConcept({...ilpConcept, description: e.target.value})}
                    className="mt-2 min-h-[150px]"
                  />
                </div>
                {ilpConcept.pillars.map((pillar, index) => (
                  <div key={index} className="border-t border-[#D4C5B0] pt-4 mt-4">
                    <h3 className="font-semibold text-[#3E2723] mb-4">Pillar {index + 1}: {pillar.name}</h3>
                    <div className="space-y-3">
                      <div>
                        <Label>Name</Label>
                        <Input
                          value={pillar.name}
                          onChange={(e) => {
                            const updated = {...ilpConcept};
                            updated.pillars[index].name = e.target.value;
                            setIlpConcept(updated);
                          }}
                          className="mt-2"
                        />
                      </div>
                      <div>
                        <Label>Description</Label>
                        <Textarea
                          value={pillar.description}
                          onChange={(e) => {
                            const updated = {...ilpConcept};
                            updated.pillars[index].description = e.target.value;
                            setIlpConcept(updated);
                          }}
                          className="mt-2"
                        />
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </TabsContent>

          {/* Vision Board Tab */}
          <TabsContent value="vision">
            <div className="bg-white rounded-3xl p-8 border border-[#D4C5B0] shadow-lg">
              <h2 className="text-2xl font-bold text-[#3E2723] mb-6">Vision Board</h2>
              <div className="space-y-6">
                <div>
                  <Label htmlFor="visionTitle">Title</Label>
                  <Input
                    id="visionTitle"
                    value={visionBoard.title}
                    onChange={(e) => setVisionBoard({...visionBoard, title: e.target.value})}
                    className="mt-2"
                  />
                </div>
                <div>
                  <Label htmlFor="visionReflection">Reflection</Label>
                  <Textarea
                    id="visionReflection"
                    value={visionBoard.reflection}
                    onChange={(e) => setVisionBoard({...visionBoard, reflection: e.target.value})}
                    className="mt-2 min-h-[150px]"
                  />
                </div>
                
                <div className="border-t border-[#D4C5B0] pt-6 mt-6">
                  <h3 className="font-semibold text-[#3E2723] mb-4">Vision Elements</h3>
                  {visionBoard.elements.map((element, index) => (
                    <div key={element.id} className="mb-6 p-4 bg-[#FAF8F3] rounded-lg">
                      <h4 className="font-medium text-[#3E2723] mb-3">Element {index + 1}</h4>
                      <div className="space-y-3">
                        <Input
                          value={element.title}
                          onChange={(e) => {
                            const updated = {...visionBoard};
                            updated.elements[index].title = e.target.value;
                            setVisionBoard(updated);
                          }}
                          placeholder="Title"
                        />
                        <Textarea
                          value={element.description}
                          onChange={(e) => {
                            const updated = {...visionBoard};
                            updated.elements[index].description = e.target.value;
                            setVisionBoard(updated);
                          }}
                          placeholder="Description"
                          className="min-h-[80px]"
                        />
                        <Input
                          value={element.image}
                          onChange={(e) => {
                            const updated = {...visionBoard};
                            updated.elements[index].image = e.target.value;
                            setVisionBoard(updated);
                          }}
                          placeholder="Image URL"
                        />
                      </div>
                    </div>
                  ))}
                </div>

                <div className="border-t border-[#D4C5B0] pt-6 mt-6">
                  <h3 className="font-semibold text-[#3E2723] mb-4">Quotes</h3>
                  {visionBoard.quotes.map((quote, index) => (
                    <Textarea
                      key={index}
                      value={quote}
                      onChange={(e) => {
                        const updated = {...visionBoard};
                        updated.quotes[index] = e.target.value;
                        setVisionBoard(updated);
                      }}
                      className="mt-3 min-h-[80px]"
                      placeholder={`Quote ${index + 1}`}
                    />
                  ))}
                </div>
              </div>
            </div>
          </TabsContent>

          {/* Projects Tab */}
          <TabsContent value="projects">
            <div className="space-y-6">
              {projects.map((project, index) => (
                <div key={project.id} className="bg-white rounded-3xl p-8 border border-[#D4C5B0] shadow-lg">
                  <h2 className="text-2xl font-bold text-[#3E2723] mb-6">Project {index + 1}</h2>
                  <div className="space-y-4">
                    <div>
                      <Label>Title</Label>
                      <Input
                        value={project.title}
                        onChange={(e) => {
                          const updated = [...projects];
                          updated[index].title = e.target.value;
                          setProjects(updated);
                        }}
                        className="mt-2"
                      />
                    </div>
                    <div>
                      <Label>Course</Label>
                      <Input
                        value={project.course}
                        onChange={(e) => {
                          const updated = [...projects];
                          updated[index].course = e.target.value;
                          setProjects(updated);
                        }}
                        className="mt-2"
                      />
                    </div>
                    <div>
                      <Label>Description</Label>
                      <Textarea
                        value={project.description}
                        onChange={(e) => {
                          const updated = [...projects];
                          updated[index].description = e.target.value;
                          setProjects(updated);
                        }}
                        className="mt-2 min-h-[100px]"
                      />
                    </div>
                    <div>
                      <Label>Image URL</Label>
                      <Input
                        value={project.image}
                        onChange={(e) => {
                          const updated = [...projects];
                          updated[index].image = e.target.value;
                          setProjects(updated);
                        }}
                        className="mt-2"
                      />
                    </div>
                    <div>
                      <Label>Skills (comma-separated)</Label>
                      <Input
                        value={project.skills.join(', ')}
                        onChange={(e) => {
                          const updated = [...projects];
                          updated[index].skills = e.target.value.split(',').map(s => s.trim());
                          setProjects(updated);
                        }}
                        className="mt-2"
                      />
                    </div>
                    <div>
                      <Label>Artifacts</Label>
                      {project.artifacts.map((artifact, aIndex) => (
                        <Input
                          key={aIndex}
                          value={artifact}
                          onChange={(e) => {
                            const updated = [...projects];
                            updated[index].artifacts[aIndex] = e.target.value;
                            setProjects(updated);
                          }}
                          className="mt-2"
                          placeholder={`Artifact ${aIndex + 1}`}
                        />
                      ))}
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </TabsContent>
        </Tabs>

        {/* Save Button at Bottom */}
        <div className="mt-8 flex justify-center">
          <Button 
            onClick={handleSave} 
            disabled={saving}
            className="bg-[#C9A961] hover:bg-[#B89551] text-white"
            size="lg"
          >
            {saving ? (
              <>Saving...</>
            ) : (
              <>
                <Save className="mr-2" size={20} />
                Save All Changes
              </>
            )}
          </Button>
        </div>
      </div>
    </div>
  );
};

export default Editor;

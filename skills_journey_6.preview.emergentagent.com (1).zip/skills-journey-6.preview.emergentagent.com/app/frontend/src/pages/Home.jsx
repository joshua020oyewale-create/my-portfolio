import React from 'react';
import { Link } from 'react-router-dom';
import { ArrowRight, BookOpen, Target, Heart } from 'lucide-react';
import { personalInfo } from '../data/mock';
import { Button } from '../components/ui/button';

const Home = () => {
  return (
    <div className="min-h-screen">
      {/* Hero Section */}
      <section className="relative h-screen flex items-center justify-center bg-gradient-to-br from-[#F5F1E8] via-[#FAF8F3] to-[#D4C5B0] overflow-hidden">
        <div className="absolute inset-0 opacity-10">
          <div className="absolute top-20 left-10 w-72 h-72 bg-[#C9A961] rounded-full filter blur-3xl"></div>
          <div className="absolute bottom-20 right-10 w-96 h-96 bg-[#C89F91] rounded-full filter blur-3xl"></div>
        </div>
        
        <div className="relative z-10 text-center px-6 max-w-5xl mx-auto">
          <h1
            className="text-5xl md:text-7xl lg:text-8xl font-bold text-[#3E2723] mb-6 leading-tight"
            style={{ fontFamily: 'Playfair Display, serif' }}
          >
            Learn. Serve. Heal.
          </h1>
          <p className="text-xl md:text-2xl text-[#4A403A] mb-4 max-w-3xl mx-auto leading-relaxed">
            {personalInfo.name} - {personalInfo.title}
          </p>
          <p className="text-lg md:text-xl text-[#6B5D54] mb-10 max-w-2xl mx-auto">
            {personalInfo.university}
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center items-center">
            <Link to="/about">
              <Button
                size="lg"
                className="bg-[#C9A961] hover:bg-[#B89551] text-white px-8 py-6 text-lg rounded-full transition-all transform hover:scale-105 shadow-lg"
              >
                Explore My Journey
                <ArrowRight className="ml-2" size={20} />
              </Button>
            </Link>
            <Link to="/mission">
              <Button
                size="lg"
                variant="outline"
                className="border-2 border-[#C9A961] text-[#C9A961] hover:bg-[#C9A961] hover:text-white px-8 py-6 text-lg rounded-full transition-all transform hover:scale-105"
              >
                Read My Mission
              </Button>
            </Link>
          </div>
        </div>
      </section>

      {/* Quick Navigation Cards */}
      <section className="py-20 px-6 bg-[#FAF8F3]">
        <div className="max-w-7xl mx-auto">
          <h2
            className="text-4xl md:text-5xl font-bold text-[#3E2723] text-center mb-16"
            style={{ fontFamily: 'Playfair Display, serif' }}
          >
            My Portfolio
          </h2>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            {/* Strengths Card */}
            <Link to="/strengths/adaptability" className="group">
              <div className="bg-white rounded-2xl p-8 shadow-md hover:shadow-2xl transition-all transform hover:-translate-y-2 border border-[#D4C5B0] h-full">
                <div className="w-16 h-16 bg-[#C9A961] bg-opacity-20 rounded-full flex items-center justify-center mb-6 group-hover:bg-opacity-30 transition-all">
                  <BookOpen className="text-[#C9A961]" size={32} />
                </div>
                <h3 className="text-2xl font-bold text-[#3E2723] mb-4">Transferable Skills</h3>
                <p className="text-[#6B5D54] leading-relaxed">
                  Explore the 8 core strengths that define my journey toward becoming a compassionate physician.
                </p>
              </div>
            </Link>

            {/* Vision Card */}
            <Link to="/vision" className="group">
              <div className="bg-white rounded-2xl p-8 shadow-md hover:shadow-2xl transition-all transform hover:-translate-y-2 border border-[#D4C5B0] h-full">
                <div className="w-16 h-16 bg-[#C89F91] bg-opacity-20 rounded-full flex items-center justify-center mb-6 group-hover:bg-opacity-30 transition-all">
                  <Target className="text-[#C89F91]" size={32} />
                </div>
                <h3 className="text-2xl font-bold text-[#3E2723] mb-4">Vision Board</h3>
                <p className="text-[#6B5D54] leading-relaxed">
                  Discover my aspirations and the milestones guiding my path to medical school and beyond.
                </p>
              </div>
            </Link>

            {/* Projects Card */}
            <Link to="/projects" className="group">
              <div className="bg-white rounded-2xl p-8 shadow-md hover:shadow-2xl transition-all transform hover:-translate-y-2 border border-[#D4C5B0] h-full">
                <div className="w-16 h-16 bg-[#B8AFA4] bg-opacity-20 rounded-full flex items-center justify-center mb-6 group-hover:bg-opacity-30 transition-all">
                  <Heart className="text-[#B8AFA4]" size={32} />
                </div>
                <h3 className="text-2xl font-bold text-[#3E2723] mb-4">Academic Projects</h3>
                <p className="text-[#6B5D54] leading-relaxed">
                  Review my coursework in bioinformatics and conservation biology demonstrating applied learning.
                </p>
              </div>
            </Link>
          </div>
        </div>
      </section>

      {/* Featured Quote */}
      <section className="py-20 px-6 bg-[#3E2723]">
        <div className="max-w-4xl mx-auto text-center">
          <blockquote className="text-2xl md:text-3xl text-[#FAF8F3] leading-relaxed italic mb-6" style={{ fontFamily: 'Playfair Display, serif' }}>
            "Success isn't just reaching medical school, it's becoming someone who learns deeply, lives humbly, and is compassionate to all."
          </blockquote>
          <p className="text-[#D4C5B0] text-lg">- Joshua</p>
        </div>
      </section>
    </div>
  );
};

export default Home;

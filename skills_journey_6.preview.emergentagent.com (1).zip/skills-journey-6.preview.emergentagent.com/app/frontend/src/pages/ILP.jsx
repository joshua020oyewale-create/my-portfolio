import React from 'react';
import { ilpConcept } from '../data/mock';
import { Heart, TrendingUp, Target, Scale } from 'lucide-react';

const ILP = () => {
  const iconMap = {
    Heart: Heart,
    TrendingUp: TrendingUp,
    Target: Target,
    Scale: Scale
  };

  return (
    <div className="min-h-screen bg-[#FAF8F3] py-24 px-6">
      <div className="max-w-6xl mx-auto">
        {/* Header */}
        <div className="text-center mb-16">
          <h1
            className="text-5xl md:text-6xl font-bold text-[#3E2723] mb-6"
            style={{ fontFamily: 'Playfair Display, serif' }}
          >
            {ilpConcept.title}
          </h1>
          <div className="w-24 h-1 bg-[#C9A961] mx-auto mb-8"></div>
        </div>

        {/* Main Description */}
        <div className="bg-white rounded-3xl shadow-lg p-10 md:p-12 mb-16 border border-[#D4C5B0]">
          <p className="text-xl text-[#4A403A] leading-relaxed text-center">
            {ilpConcept.description}
          </p>
        </div>

        {/* ILP Framework Diagram */}
        <div className="mb-16">
          <h2
            className="text-4xl font-bold text-[#3E2723] text-center mb-12"
            style={{ fontFamily: 'Playfair Display, serif' }}
          >
            My ILP Framework
          </h2>
          
          {/* Visual Framework */}
          <div className="relative">
            {/* Center Circle */}
            <div className="flex justify-center mb-12">
              <div className="w-48 h-48 bg-gradient-to-br from-[#C9A961] to-[#C89F91] rounded-full flex items-center justify-center shadow-2xl">
                <div className="text-center text-white">
                  <p className="text-2xl font-bold" style={{ fontFamily: 'Playfair Display, serif' }}>Medicine as</p>
                  <p className="text-3xl font-bold" style={{ fontFamily: 'Playfair Display, serif' }}>Calling</p>
                </div>
              </div>
            </div>

            {/* Pillars Grid */}
            <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
              {ilpConcept.pillars.map((pillar, index) => {
                const IconComponent = iconMap[pillar.icon];
                return (
                  <div
                    key={index}
                    className="bg-white rounded-2xl p-8 shadow-lg border-2 border-[#D4C5B0] hover:border-[#C9A961] transition-all transform hover:-translate-y-2"
                  >
                    <div className="flex items-start gap-6">
                      <div className="w-16 h-16 bg-[#C9A961] bg-opacity-20 rounded-full flex items-center justify-center flex-shrink-0">
                        <IconComponent className="text-[#C9A961]" size={32} />
                      </div>
                      <div>
                        <h3 className="text-2xl font-bold text-[#3E2723] mb-3">{pillar.name}</h3>
                        <p className="text-[#4A403A] leading-relaxed">{pillar.description}</p>
                      </div>
                    </div>
                  </div>
                );
              })}
            </div>
          </div>
        </div>

        {/* Integration Section */}
        <div className="bg-gradient-to-br from-[#3E2723] to-[#4A403A] rounded-3xl shadow-2xl p-10 md:p-12 text-white">
          <h2
            className="text-3xl font-bold mb-6 text-center"
            style={{ fontFamily: 'Playfair Display, serif' }}
          >
            Integration in Action
          </h2>
          <p className="text-lg leading-relaxed text-center max-w-3xl mx-auto">
            My Integrative Life Planning approach recognizes that success in medicine requires more
            than academic excellence. It demands a holistic commitment to personal growth, community
            service, and purposeful living. By balancing these four pillars—Service, Growth, Purpose,
            and Balance—I ensure that my path to becoming a physician aligns with my deepest values
            and creates sustainable, meaningful impact.
          </p>
        </div>
      </div>
    </div>
  );
};

export default ILP;

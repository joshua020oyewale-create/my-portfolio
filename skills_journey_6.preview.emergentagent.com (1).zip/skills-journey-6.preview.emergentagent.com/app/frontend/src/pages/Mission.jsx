import React from 'react';
import { missionStatement } from '../data/mock';
import { Heart, Users, BookOpen, Target } from 'lucide-react';

const Mission = () => {
  const values = [
    {
      icon: Heart,
      title: 'Compassion',
      description: 'Using empathy as the foundation for all patient interactions and community service.'
    },
    {
      icon: BookOpen,
      title: 'Lifelong Learning',
      description: 'Committing to continuous growth through education, reflection, and experience.'
    },
    {
      icon: Users,
      title: 'Service',
      description: 'Dedicating myself to uplifting communities and creating equitable healthcare access.'
    },
    {
      icon: Target,
      title: 'Excellence',
      description: 'Striving for the highest standards in both personal development and professional practice.'
    }
  ];

  return (
    <div className="min-h-screen bg-[#FAF8F3] py-24 px-6">
      <div className="max-w-5xl mx-auto">
        {/* Header */}
        <div className="text-center mb-16">
          <h1
            className="text-5xl md:text-6xl font-bold text-[#3E2723] mb-6"
            style={{ fontFamily: 'Playfair Display, serif' }}
          >
            My Mission Statement
          </h1>
          <div className="w-24 h-1 bg-[#C9A961] mx-auto mb-8"></div>
        </div>

        {/* Mission Statement */}
        <div className="bg-gradient-to-br from-[#3E2723] to-[#4A403A] rounded-3xl shadow-2xl p-10 md:p-16 mb-16">
          <blockquote
            className="text-2xl md:text-3xl text-[#FAF8F3] leading-relaxed text-center italic"
            style={{ fontFamily: 'Playfair Display, serif' }}
          >
            "{missionStatement}"
          </blockquote>
        </div>

        {/* Core Values */}
        <div className="mb-16">
          <h2
            className="text-4xl font-bold text-[#3E2723] text-center mb-12"
            style={{ fontFamily: 'Playfair Display, serif' }}
          >
            Core Values
          </h2>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
            {values.map((value, index) => {
              const IconComponent = value.icon;
              return (
                <div
                  key={index}
                  className="bg-white rounded-2xl p-8 shadow-lg border border-[#D4C5B0] hover:shadow-xl transition-all transform hover:-translate-y-1"
                >
                  <div className="w-16 h-16 bg-[#C9A961] bg-opacity-20 rounded-full flex items-center justify-center mb-6">
                    <IconComponent className="text-[#C9A961]" size={32} />
                  </div>
                  <h3 className="text-2xl font-bold text-[#3E2723] mb-4">{value.title}</h3>
                  <p className="text-[#4A403A] leading-relaxed">{value.description}</p>
                </div>
              );
            })}
          </div>
        </div>

        {/* Vision Statement */}
        <div className="bg-white rounded-3xl shadow-lg p-10 md:p-12 border border-[#D4C5B0]">
          <h2
            className="text-3xl font-bold text-[#3E2723] mb-6 text-center"
            style={{ fontFamily: 'Playfair Display, serif' }}
          >
            My Vision
          </h2>
          <p className="text-lg text-[#4A403A] leading-relaxed text-center max-w-3xl mx-auto">
            I envision a future where I contribute to healthcare as a physician who not only treats
            illness but addresses the whole person, their fears, hopes, and circumstances. Through
            dedication to science, unwavering compassion, and a commitment to equity, I will work to
            create a healthcare system that serves all communities with dignity and respect.
          </p>
        </div>
      </div>
    </div>
  );
};

export default Mission;

import React from 'react';
import { ExternalLink, FileText } from 'lucide-react';
import { Button } from '../components/ui/button';

// ===========================
// YOUR TWO ACTUAL PROJECTS
// ===========================
const projects = [
  {
    id: 1,
    title: "BRCA2 Gene Bioinformatics Review",
    course: "BIO 333 – Bioinformatics",
    image: "https://www.halodx.com/wp-content/uploads/2022/09/MicrosoftTeams-image-6.jpg", // <- replace with your actual image if you want
    description:
      "A comprehensive bioinformatics analysis of the BRCA2 gene involving pairwise alignment, multiple sequence alignment, genome browser visualization, phylogenetic analysis, and protein structure prediction.",
    skills: [
      "Bioinformatics",
      "Sequence Alignment",
      "Phylogenetics",
      "Genome Analysis",
      "Scientific Writing"
    ],
    artifacts: [
      { 
        label: "Full Project Report (PDF)", 
        url: "/pdfs/Review-a-gene-project-final.pdf"  // <-- Your uploaded file
      }
    ]
  },
  {
    id: 2,
    title: "Saving Southern Resident Killer Whales",
    course: "BIO 310 – Conservation Biology",
    image: "https://cdn.theatlantic.com/thumbor/0AeFF0OVHRBqCuNxOUMIplLQc50=/0x214:4114x2528/1952x1098/media/img/mt/2019/04/shutterstock_554899423_1/original.jpg", // <- replace if needed
    description:
      "A conservation policy pitch proposing an AI-powered protection system for endangered Southern Resident Killer Whales, addressing ecological, social, and economic impacts.",
    skills: [
      "Policy Analysis",
      "Conservation Biology",
      "Science Communication",
      "Public Engagement",
      "Environmental Advocacy"
    ],
    artifacts: [
      { 
        label: "Policy Pitch Presentation (PPTX)", 
        url: "/pdfs/Saving-Southern-Resident-Killer-Whales.pptx" // <-- Your uploaded file
      }
    ]
  }
];

// ===========================
// MAIN COMPONENT
// ===========================
const Projects = () => {
  return (
    <div className="min-h-screen bg-[#FAF8F3] py-24 px-6">
      <div className="max-w-6xl mx-auto">

        {/* Header */}
        <div className="text-center mb-16">
          <h1
            className="text-5xl md:text-6xl font-bold text-[#3E2723] mb-6"
            style={{ fontFamily: 'Playfair Display, serif' }}
          >
            Academic Projects
          </h1>
          <div className="w-24 h-1 bg-[#C9A961] mx-auto mb-8"></div>
          <p className="text-xl text-[#4A403A] max-w-3xl mx-auto leading-relaxed">
            A showcase of academic work demonstrating applied learning in biotechnology,
            bioinformatics, and conservation biology. These projects reflect my commitment to
            scientific inquiry, communication, and real-world problem solving.
          </p>
        </div>

        {/* Projects */}
        <div className="space-y-12">
          {projects.map((project) => (
            <div
              key={project.id}
              className="bg-white rounded-3xl overflow-hidden shadow-lg border border-[#D4C5B0] hover:shadow-2xl transition-all"
            >
              <div className="grid grid-cols-1 lg:grid-cols-2 gap-0">

                {/* Image */}
                <div className="h-80 lg:h-auto overflow-hidden">
                  <img
                    src={project.image}
                    alt={project.title}
                    className="w-full h-full object-cover"
                  />
                </div>

                {/* Content */}
                <div className="p-10 flex flex-col justify-between">
                  <div>
                    <div className="inline-block bg-[#C9A961] bg-opacity-20 px-4 py-2 rounded-full mb-4">
                      <span className="text-[#C9A961] font-semibold text-sm uppercase tracking-wide">
                        {project.course}
                      </span>
                    </div>

                    <h2
                      className="text-3xl font-bold text-[#3E2723] mb-4"
                      style={{ fontFamily: 'Playfair Display, serif' }}
                    >
                      {project.title}
                    </h2>

                    <p className="text-lg text-[#4A403A] leading-relaxed mb-6">
                      {project.description}
                    </p>

                    {/* Skills */}
                    <div className="mb-6">
                      <h3 className="text-lg font-semibold text-[#3E2723] mb-3">Skills Demonstrated</h3>
                      <div className="flex flex-wrap gap-2">
                        {project.skills.map((skill, index) => (
                          <span
                            key={index}
                            className="bg-[#F5F1E8] text-[#4A403A] px-3 py-1 rounded-full text-sm font-medium"
                          >
                            {skill}
                          </span>
                        ))}
                      </div>
                    </div>

                    {/* Artifacts */}
                    <div className="mb-6">
                      <h3 className="text-lg font-semibold text-[#3E2723] mb-3">Project Artifacts</h3>
                      <ul className="space-y-2">
                        {project.artifacts.map((artifact, index) => (
                          <li key={index} className="flex items-start gap-2 text-[#4A403A]">
                            <FileText className="text-[#C9A961] flex-shrink-0 mt-1" size={18} />
                            {artifact.url ? (
                              <a
                                href={artifact.url}
                                target="_blank"
                                rel="noopener noreferrer"
                                className="text-[#3E2723] font-medium underline hover:text-[#C9A961] transition-colors"
                              >
                                {artifact.label}
                              </a>
                            ) : (
                              <span>{artifact.label}</span>
                            )}
                          </li>
                        ))}
                      </ul>
                    </div>
                  </div>

                  {/* View Button (optional placeholder) */}
                  <div>
                    <Button className="bg-[#C9A961] hover:bg-[#B89551] text-white w-full rounded-full">
                      View Project Details
                      <ExternalLink className="ml-2" size={18} />
                    </Button>
                  </div>

                </div>
              </div>
            </div>
          ))}
        </div>

        {/* Bottom Section */}
        <div className="mt-16 bg-gradient-to-br from-[#3E2723] to-[#4A403A] rounded-3xl shadow-2xl p-10 md:p-12 text-white">
          <h2
            className="text-3xl font-bold mb-6 text-center"
            style={{ fontFamily: 'Playfair Display, serif' }}
          >
            Connecting Research to Medicine
          </h2>
          <p className="text-lg leading-relaxed text-center max-w-3xl mx-auto">
            These projects demonstrate my ability to analyze data, interpret biological systems,
            and communicate complex scientific findings. Whether studying gene evolution or
            designing conservation policies, I approach every project with curiosity, precision,
            and purpose qualities essential for a future physician.
          </p>
        </div>

      </div>
    </div>
  );
};

export default Projects;

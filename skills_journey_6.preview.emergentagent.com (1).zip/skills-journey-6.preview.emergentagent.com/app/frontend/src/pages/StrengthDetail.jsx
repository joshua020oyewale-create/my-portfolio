import React from 'react';
import { useParams, Link } from 'react-router-dom';
import { transferableSkills } from '../data/mock';
import { ArrowLeft, ArrowRight, CheckCircle } from 'lucide-react';
import { Button } from '../components/ui/button';

const StrengthDetail = () => {
  const { strengthId } = useParams();
  
  const skill = transferableSkills.find(
    (s) => s.name.toLowerCase().replace(/\s+&?\s*/g, '-') === strengthId
  );

  if (!skill) {
    return (
      <div className="min-h-screen bg-[#FAF8F3] py-24 px-6 flex items-center justify-center">
        <div className="text-center">
          <h1 className="text-4xl font-bold text-[#3E2723] mb-4">Skill Not Found</h1>
          <Link to="/strengths/adaptability">
            <Button className="bg-[#C9A961] hover:bg-[#B89551] text-white">
              Back to Strengths
            </Button>
          </Link>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-[#FAF8F3] py-24 px-6">
      <div className="max-w-5xl mx-auto">
        {/* Back Button */}
        <Link to="/strengths/adaptability">
          <Button
            variant="outline"
            className="mb-8 border-[#C9A961] text-[#C9A961] hover:bg-[#C9A961] hover:text-white"
          >
            <ArrowLeft className="mr-2" size={20} />
            Back to All Strengths
          </Button>
        </Link>

        {/* Header Image */}
        <div className="rounded-3xl overflow-hidden shadow-2xl mb-12 h-96">
          <img
            src={skill.image}
            alt={skill.name}
            className="w-full h-full object-cover"
          />
        </div>

        {/* Title Section */}
        <div className="text-center mb-12">
          <h1
            className="text-5xl md:text-6xl font-bold text-[#3E2723] mb-4"
            style={{ fontFamily: 'Playfair Display, serif' }}
          >
            {skill.name}
          </h1>
          <p className="text-xl text-[#C9A961] font-semibold uppercase tracking-wide">
            {skill.tagline}
          </p>
          <div className="w-24 h-1 bg-[#C9A961] mx-auto mt-6"></div>
        </div>

        {/* Description */}
        <div className="bg-white rounded-3xl shadow-lg p-10 md:p-12 mb-12 border border-[#D4C5B0]">
          <h2 className="text-3xl font-bold text-[#3E2723] mb-6" style={{ fontFamily: 'Playfair Display, serif' }}>
            Personal Reflection
          </h2>
          <p className="text-lg text-[#4A403A] leading-relaxed mb-6">
            {skill.fullReflection}
          </p>
        </div>

        {/* Medical Connection */}
        <div className="bg-gradient-to-br from-[#C9A961] to-[#C89F91] rounded-3xl shadow-lg p-10 md:p-12 mb-12 text-white">
          <h2 className="text-3xl font-bold mb-6" style={{ fontFamily: 'Playfair Display, serif' }}>
            Application in Medicine
          </h2>
          <p className="text-lg leading-relaxed">
            {skill.medicalConnection}
          </p>
        </div>

        {/* Examples */}
        <div className="bg-white rounded-3xl shadow-lg p-10 md:p-12 border border-[#D4C5B0]">
          <h2 className="text-3xl font-bold text-[#3E2723] mb-8" style={{ fontFamily: 'Playfair Display, serif' }}>
            Real-World Examples
          </h2>
          <div className="space-y-4">
            {skill.examples.map((example, index) => (
              <div key={index} className="flex items-start gap-4">
                <CheckCircle className="text-[#C9A961] flex-shrink-0 mt-1" size={24} />
                <p className="text-lg text-[#4A403A] leading-relaxed">{example}</p>
              </div>
            ))}
          </div>
        </div>

        {/* Navigation to Next Skill */}
        <div className="mt-12 flex justify-between items-center">
          {skill.id > 1 && (
            <Link to={`/strengths/${transferableSkills[skill.id - 2].name.toLowerCase().replace(/\s+&?\s*/g, '-')}`}>
              <Button
                variant="outline"
                className="border-[#C9A961] text-[#C9A961] hover:bg-[#C9A961] hover:text-white"
              >
                <ArrowLeft className="mr-2" size={20} />
                Previous Skill
              </Button>
            </Link>
          )}
          {skill.id < transferableSkills.length && (
            <Link to={`/strengths/${transferableSkills[skill.id].name.toLowerCase().replace(/\s+&?\s*/g, '-')}`} className="ml-auto">
              <Button className="bg-[#C9A961] hover:bg-[#B89551] text-white">
                Next Skill
                <ArrowRight className="ml-2" size={20} />
              </Button>
            </Link>
          )}
        </div>
      </div>
    </div>
  );
};

export default StrengthDetail;

import React from 'react';
import { Link } from 'react-router-dom';
import { transferableSkills } from '../data/mock';
import { ArrowRight } from 'lucide-react';

const StrengthsOverview = () => {
  return (
    <div className="min-h-screen bg-[#FAF8F3] py-24 px-6">
      <div className="max-w-7xl mx-auto">
        {/* Header */}
        <div className="text-center mb-16">
          <h1
            className="text-5xl md:text-6xl font-bold text-[#3E2723] mb-6"
            style={{ fontFamily: 'Playfair Display, serif' }}
          >
            Transferable Skills
          </h1>
          <div className="w-24 h-1 bg-[#C9A961] mx-auto mb-8"></div>
          <p className="text-xl text-[#4A403A] max-w-3xl mx-auto leading-relaxed">
            These eight core strengths have shaped my journey and continue to prepare me for a career
            in medicine. Each skill represents not just an ability, but a commitment to continuous
            growth and excellence.
          </p>
        </div>

        {/* Skills Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-2 gap-8">
          {transferableSkills.map((skill) => {
            const skillSlug = skill.name.toLowerCase().replace(/\s+&?\s*/g, '-');
            return (
              <Link
                key={skill.id}
                to={`/strengths/${skillSlug}`}
                className="group bg-white rounded-3xl overflow-hidden shadow-lg hover:shadow-2xl transition-all transform hover:-translate-y-2 border border-[#D4C5B0]"
              >
                {/* Image */}
                <div className="h-64 overflow-hidden">
                  <img
                    src={skill.image}
                    alt={skill.name}
                    className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-500"
                  />
                </div>

                {/* Content */}
                <div className="p-8">
                  <h3 className="text-3xl font-bold text-[#3E2723] mb-3" style={{ fontFamily: 'Playfair Display, serif' }}>
                    {skill.name}
                  </h3>
                  <p className="text-sm text-[#C9A961] font-semibold mb-4 uppercase tracking-wide">
                    {skill.tagline}
                  </p>
                  <p className="text-[#4A403A] leading-relaxed mb-6">
                    {skill.description}
                  </p>
                  <div className="flex items-center text-[#C9A961] font-semibold group-hover:translate-x-2 transition-transform">
                    Learn More
                    <ArrowRight className="ml-2" size={20} />
                  </div>
                </div>
              </Link>
            );
          })}
        </div>
      </div>
    </div>
  );
};

export default StrengthsOverview;

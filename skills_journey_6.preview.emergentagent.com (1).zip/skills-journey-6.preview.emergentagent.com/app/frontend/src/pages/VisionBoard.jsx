import React from 'react';
import { visionBoard } from '../data/mock';

const VisionBoard = () => {
  return (
    <div className="min-h-screen bg-[#FAF8F3] py-24 px-6">
      <div className="max-w-7xl mx-auto">
        {/* Header */}
        <div className="text-center mb-16">
          <h1
            className="text-5xl md:text-6xl font-bold text-[#3E2723] mb-6"
            style={{ fontFamily: 'Playfair Display, serif' }}
          >
            {visionBoard.title}
          </h1>
          <div className="w-24 h-1 bg-[#C9A961] mx-auto mb-8"></div>
        </div>

        {/* Vision Board Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 mb-16">
          {visionBoard.elements.map((element) => (
            <div
              key={element.id}
              className="group bg-white rounded-2xl overflow-hidden shadow-lg hover:shadow-2xl transition-all transform hover:-translate-y-2 border border-[#D4C5B0]"
            >
              <div className="h-64 overflow-hidden">
                <img
                  src={element.image}
                  alt={element.title}
                  className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-500"
                />
              </div>
              <div className="p-6">
                <h3 className="text-xl font-bold text-[#3E2723] mb-3">
                  {element.title}
                </h3>
                <p className="text-[#4A403A] leading-relaxed">
                  {element.description}
                </p>
              </div>
            </div>
          ))}
        </div>

        {/* Reflection */}
        <div className="bg-white rounded-3xl shadow-lg p-10 md:p-12 mb-12 border border-[#D4C5B0]">
          <h2
            className="text-3xl font-bold text-[#3E2723] mb-6 text-center"
            style={{ fontFamily: 'Playfair Display, serif' }}
          >
            Vision Board Reflection
          </h2>
          <p className="text-lg text-[#4A403A] leading-relaxed">
            {visionBoard.reflection}
          </p>
        </div>

        {/* Inspirational Quotes */}
        <div className="space-y-6">
          {visionBoard.quotes.map((quote, index) => (
            <div
              key={index}
              className="bg-gradient-to-br from-[#C9A961] to-[#C89F91] rounded-2xl shadow-lg p-8 text-center"
            >
              <blockquote
                className="text-xl md:text-2xl text-white italic"
                style={{ fontFamily: 'Playfair Display, serif' }}
              >
                "{quote}"
              </blockquote>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};

export default VisionBoard;
